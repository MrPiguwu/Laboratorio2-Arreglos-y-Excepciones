package vista;

public class Vista {
    public void Menu(){

    }

}
